自动点击网页中烦人的“阅读更多”

解决网页上烦人的“阅读更多”问题。
最近在CSDN、百度知道等网页浏览的时候，总是出现页面内容被折叠的情况。每次都需要手动点击查看更多，比较烦人，于是就自己写了一个chrome插件来实现自动点击。
源代码地址放在github上了：https://github.com/jeeinn/crx-clicked-and-read